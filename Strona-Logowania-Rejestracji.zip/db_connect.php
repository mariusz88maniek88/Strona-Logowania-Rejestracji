<?php 

$db_host = "localhost";
$db_user = "mariusz888";
$db_pass = "mariusz888";
$db_name = "users";

$db_connect = new mysqli($db_host, $db_user, $db_pass, $db_name);

?>
